import Link from "next/link";
import { Question } from "@/types";
import SearchResultQuestionVotes from "@/components/SearchResultQuestionVotes";
import UserAvatar from "@/components/UserAvatar";
import PremiumQuestionCardBadge from "@/components/PremiumQuestionCardBadge";
import { displayPremiumBadge, displayUserName } from "@/lib/ai-user-display";

interface SearchResultCardProps {
  question: Question;
  isProfilePage?: boolean;
  status?: "opened" | "voting" | "closed";
  /** Число проголосовавших (лайки + дизлайки), для строки «Проголосовало N человека» */
  votesCount?: number;
  isOwnProfile?: boolean;
  answersCountOverride?: number;
  /** Показать блок лайк/дизлайк с актуальными счётчиками и голосом текущего пользователя */
  showQuestionVotes?: boolean;
  likesCount?: number;
  dislikesCount?: number;
  userVote?: 1 | -1 | null;
}

// Склонение ответов
const numWord = (value: number, words: [string, string, string]): string => {
  const abs = Math.abs(value);
  const cases = [2, 0, 1, 1, 1, 2];
  const index =
    abs % 100 > 4 && abs % 100 < 20 ? 2 : cases[Math.min(abs % 10, 5)];
  return `${value} ${words[index]}`;
};

// Форматирование даты
const formatTimeAgo = (dateStr: string): string => {
  const now = new Date();
  const date = new Date(dateStr);
  const diffMs = now.getTime() - date.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays < 1) return "сегодня";
  if (diffDays < 7)
    return numWord(diffDays, ["день", "дня", "дней"]) + " назад";

  const diffWeeks = Math.floor(diffDays / 7);
  if (diffWeeks < 4)
    return numWord(diffWeeks, ["неделю", "недели", "недель"]) + " назад";

  const diffMonths = Math.floor(diffDays / 30);
  if (diffMonths < 12)
    return numWord(diffMonths, ["месяц", "месяца", "месяцев"]) + " назад";

  const diffYears = Math.floor(diffDays / 365);
  return numWord(diffYears, ["год", "года", "лет"]) + " назад";
};

export default function SearchResultCard({
  question,
  isProfilePage,
  status,
  votesCount = 0,
  isOwnProfile,
  answersCountOverride,
  showQuestionVotes,
  likesCount = 0,
  dislikesCount = 0,
  userVote = null,
}: SearchResultCardProps) {
  const answersCount = answersCountOverride ?? question.commentsCount ?? 0;
  const q = question as Question & { isPremium?: boolean; is_premium?: boolean };
  /** Только флаг вопроса: премиум-оформление не зависит от премиума автора/профиля */
  const isPremium = q.isPremium === true || q.is_premium === true;
  const authorPremium =
    question.author.premium_is_active ??
    question.author.is_premium ??
    false;
  const authorPremiumText = displayPremiumBadge(question.author) ?? "Премиум";
  const authorName = displayUserName(question.author);
  return (
    <div className={`search-result-card ${isPremium ? "premium-question" : ""}`}>
      <div
        className="search-result-top"
        style={{
          display: "flex",
          gap: "20px",
          alignItems: "flex-start",
        }}
      >
        {!isOwnProfile && (
          <Link
            href={`/profile/${question.author?.id ?? question.author?.username ?? ""}`}
            style={{ display: "flex", position: "relative" }}
          >
            <UserAvatar
              src={question.author?.avatar}
              src2x={question.author?.avatar2x}
              alt={authorName}
              premium={authorPremium}
              premiumText={authorPremiumText}
              size={51}
              imgClassName="search-result-avatar"
            />
          </Link>
        )}
        <div style={{ flex: 1 }}>
          <div
            style={{
              marginBottom: "4px",
              display: "flex",
              flexWrap: "wrap",
              alignItems: "center",
              columnGap: "10px",
              rowGap: "6px",
            }}
          >
            <Link
              href={`/question/${question.slug}`}
              className="search-result-title"
            >
              {question.title || "Без заголовка"}
            </Link>
            {isPremium ? <PremiumQuestionCardBadge /> : null}
          </div>
          {isOwnProfile && question.content && (
            <p
              className="search-result-subtext"
              style={{
                marginTop: "4px",
                marginBottom: "8px",
                fontSize: "14px",
                lineHeight: "1.4",
              }}
            >
              {question.content}
            </p>
          )}
          <div className="search-result-meta">
            <Link
              href={`/categories/${question.category?.slug || ""}`}
              className="search-result-category"
            >
              <svg
                width="16"
                height="16"
                className="search-result-category-icon"
              >
                <use
                  xlinkHref={`#${question.category?.svgIcon || "business"}`}
                ></use>
              </svg>
              <span className="search-result-category-name">
                {question.category?.name || "Без категории"}
              </span>
            </Link>
            <div className="search-result-separator"></div>
            <div className="search-result-date">
              {formatTimeAgo(question.createdAt)}
            </div>
            <div className="search-result-separator"></div>
            <div className="search-result-answers">
              <svg
                width="14"
                height="14"
                viewBox="0 0 14 14"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M10.8182 0H3.18182C2.33826 0.00101045 1.52954 0.336559 0.933049 0.933043C0.336561 1.52953 0.00101045 2.33824 0 3.1818V8.27267C0.000925606 9.00589 0.254603 9.71637 0.718275 10.2844C1.18195 10.8524 1.82726 11.2431 2.54545 11.3908V13.3635C2.54544 13.4788 2.5767 13.5918 2.6359 13.6906C2.6951 13.7895 2.78002 13.8704 2.8816 13.9247C2.98319 13.9791 3.09762 14.0048 3.21269 13.9993C3.32777 13.9937 3.43916 13.9569 3.535 13.893L7.19091 11.4545H10.8182C11.6617 11.4535 12.4705 11.1179 13.067 10.5214C13.6634 9.92494 13.999 9.11623 14 8.27267V3.1818C13.999 2.33824 13.6634 1.52953 13.067 0.933043C12.4705 0.336559 11.6617 0.00101045 10.8182 0ZM9.54545 7.63631H4.45455C4.28577 7.63631 4.12391 7.56927 4.00457 7.44993C3.88523 7.33059 3.81818 7.16873 3.81818 6.99995C3.81818 6.83118 3.88523 6.66932 4.00457 6.54998C4.12391 6.43064 4.28577 6.36359 4.45455 6.36359H9.54545C9.71423 6.36359 9.87609 6.43064 9.99543 6.54998C10.1148 6.66932 10.1818 6.83118 10.1818 6.99995C10.1818 7.16873 10.1148 7.33059 9.99543 7.44993C9.87609 7.56927 9.71423 7.63631 9.54545 7.63631ZM10.8182 5.09087H3.18182C3.01304 5.09087 2.85118 5.02383 2.73184 4.90449C2.6125 4.78515 2.54545 4.62329 2.54545 4.45452C2.54545 4.28574 2.6125 4.12388 2.73184 4.00454C2.85118 3.8852 3.01304 3.81816 3.18182 3.81816H10.8182C10.987 3.81816 11.1488 3.8852 11.2682 4.00454C11.3875 4.12388 11.4545 4.28574 11.4545 4.45452C11.4545 4.62329 11.3875 4.78515 11.2682 4.90449C11.1488 5.02383 10.987 5.09087 10.8182 5.09087Z"
                  fill="#6069FF"
                ></path>
              </svg>
              {numWord(answersCount, ["ответ", "ответа", "ответов"])}
            </div>
            {isProfilePage && status === "closed" && (
              <>
                <div className="search-result-separator"></div>
                <div className="search-result-status">
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 14 14"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M7 0C3.14035 0 0 3.14035 0 7C0 10.8596 3.14035 14 7 14C10.8596 14 14 10.8596 14 7C14 3.14035 10.8596 0 7 0ZM10.9123 5.15789L6.4386 9.59649C6.17544 9.85965 5.75439 9.87719 5.47368 9.61403L3.10526 7.45614C2.82456 7.19298 2.80702 6.75439 3.05263 6.47368C3.31579 6.19298 3.75439 6.17544 4.03509 6.4386L5.91228 8.1579L9.91228 4.15789C10.193 3.87719 10.6316 3.87719 10.9123 4.15789C11.193 4.4386 11.193 4.87719 10.9123 5.15789Z"
                      fill="#6069FF"
                    ></path>
                  </svg>
                  <span>Проблема решена</span>
                </div>
              </>
            )}
            {isProfilePage && status === "voting" && (
              <>
                <div className="search-result-separator"></div>
                <div className="search-result-status">
                  <svg
                    width="15"
                    height="15"
                    viewBox="0 0 15 15"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M0.0114058 7.86639C0.0170248 7.87531 0.0249291 7.88264 0.0343294 7.88762C0.0437297 7.89261 0.0542972 7.89509 0.0649767 7.89481H13.864C13.8747 7.89509 13.8853 7.89261 13.8947 7.88762C13.9041 7.88264 13.912 7.87531 13.9176 7.86639C13.924 7.85697 13.9278 7.84607 13.9287 7.83477C13.9295 7.82347 13.9274 7.81215 13.9224 7.80191L13.2777 6.40903C13.2648 6.38129 13.244 6.35776 13.2179 6.34125C13.1918 6.32474 13.1614 6.31593 13.1304 6.31587H9.91077V6.84219H10.7143C10.7854 6.84219 10.8535 6.86991 10.9037 6.91926C10.954 6.96861 10.9822 7.03555 10.9822 7.10534C10.9822 7.17513 10.954 7.24207 10.9037 7.29142C10.8535 7.34077 10.7854 7.3685 10.7143 7.3685H3.21441C3.14337 7.3685 3.07524 7.34077 3.02501 7.29142C2.97477 7.24207 2.94655 7.17513 2.94655 7.10534C2.94655 7.03555 2.97477 6.96861 3.02501 6.91926C3.07524 6.86991 3.14337 6.84219 3.21441 6.84219H4.01797V6.31587H0.79863C0.76754 6.31592 0.73712 6.32475 0.710998 6.34132C0.684877 6.35788 0.664157 6.38148 0.65131 6.4093L0.00578085 7.80402C0.00117161 7.81401 -0.000732495 7.825 0.000252998 7.83593C0.00123849 7.84685 0.0050802 7.85735 0.0114058 7.86639Z"
                      fill="#6069FF"
                    />
                    <path
                      d="M7.50008 1.05277H10.1786C10.3114 1.05061 10.4425 1.08235 10.559 1.14491C10.6755 1.20746 10.7736 1.29867 10.8434 1.40961C10.9087 1.50637 10.9509 1.61636 10.9669 1.73138C10.9829 1.8464 10.9722 1.96348 10.9357 2.07389C10.8992 2.18429 10.8378 2.28517 10.756 2.369C10.6743 2.45283 10.5743 2.51744 10.4636 2.55802L8.75498 3.1738C8.71163 3.18878 8.67206 3.21272 8.63893 3.24399C8.6058 3.27527 8.57988 3.31316 8.56292 3.35511C8.54522 3.39845 8.53702 3.44497 8.53886 3.49163C8.54071 3.53829 8.55256 3.58405 8.57364 3.6259C8.60738 3.69853 8.6684 3.75552 8.74394 3.78495C8.81947 3.81438 8.90367 3.81397 8.9789 3.78379L11.4258 2.90275C11.4436 2.89638 11.4621 2.89179 11.4809 2.88907L13.125 2.66565V0.48988L9.90273 0.00804247C9.75787 -0.0130032 9.6099 0.00746437 9.47658 0.0669893L7.50008 1.05277Z"
                      fill="#6069FF"
                    />
                    <path
                      d="M0.803719 14.7368C0.803719 14.8066 0.831939 14.8736 0.882172 14.9229C0.932404 14.9723 1.00053 15 1.07157 15H12.8572C12.9282 15 12.9963 14.9723 13.0466 14.9229C13.0968 14.8736 13.125 14.8066 13.125 14.7368V10.5264H0.803719V14.7368Z"
                      fill="#6069FF"
                    />
                    <path
                      d="M0.000155902 10H13.9286V8.41322C13.9072 8.41704 13.8857 8.41967 13.864 8.42112H0.0647088C0.0430582 8.41967 0.0215069 8.41704 0.000155902 8.41322V10Z"
                      fill="#6069FF"
                    />
                    <path
                      d="M4.55368 6.84219H9.37506V4.20774L9.16078 4.28432C8.9616 4.35741 8.74186 4.35503 8.54438 4.27763C8.3469 4.20022 8.18584 4.05335 8.09257 3.86564C8.03812 3.75703 8.00759 3.63837 8.00297 3.51739C7.99836 3.39641 8.01976 3.27584 8.06579 3.16354C8.11109 3.05324 8.17953 2.95356 8.26667 2.871C8.3538 2.78843 8.45767 2.72483 8.5715 2.68433L9.37506 2.39486V1.57908H4.55368V6.84219Z"
                      fill="#6069FF"
                    />
                    <path
                      d="M13.6607 0.263303V2.6317C13.6607 2.70149 13.6889 2.76843 13.7392 2.81778C13.7894 2.86713 13.8575 2.89486 13.9286 2.89486H14.7321C14.8032 2.89486 14.8713 2.86713 14.9215 2.81778C14.9718 2.76843 15 2.70149 15 2.6317V0.526458C15 0.456665 14.9718 0.389731 14.9215 0.34038C14.8713 0.291028 14.8032 0.263303 14.7321 0.263303H13.6607Z"
                      fill="#6069FF"
                    />
                  </svg>
                  <span>
                    Проголосовало{" "}
                    <span style={{ color: "#6069FF" }}>{votesCount}</span>{" "}
                    человека
                  </span>
                </div>
              </>
            )}
          </div>
          {showQuestionVotes && question.id ? (
            <SearchResultQuestionVotes
              questionId={question.id}
              likesCount={likesCount}
              dislikesCount={dislikesCount}
              userVote={userVote ?? null}
            />
          ) : null}
        </div>
      </div>
    </div>
  );
}
